GS Tech — projeto separado em arquivos

Estrutura:
- app.py: servidor Python usando Flask
- templates/index.html: estrutura da página
- static/style.css: estilos visuais
- static/app.js: busca, filtros, reviews e modal
- requirements.txt: dependência do servidor

Como executar:
1. Instale Python 3.
2. Abra o terminal nesta pasta.
3. Execute: pip install -r requirements.txt
4. Execute: python app.py
5. Abra no navegador: http://127.0.0.1:5000

Observação: os preços e notas são demonstrativos. O formulário de newsletter ainda não salva nem envia e-mails.
